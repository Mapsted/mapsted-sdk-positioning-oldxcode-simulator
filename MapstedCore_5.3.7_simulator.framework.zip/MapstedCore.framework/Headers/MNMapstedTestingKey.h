//
//  MNMapstedTestingKey.h
//  positioning
//
//  Created by Tianyun Shan on 2018-05-29.
//  Copyright © 2018 Mapsted. All rights reserved.
//

#ifndef MNMapstedTestingKey_h
#define MNMapstedTestingKey_h

@interface MNMapstedTestingKey : NSObject

+ (double)getOffset;
+ (void)setOffset:(double)offset;

@end


#endif /* MNMapstedTestingKey_h */
